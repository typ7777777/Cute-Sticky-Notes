Thank you for read 'Cute Sticky Notes' install guide:

Cute Sticky Notes use 'SafeUnpack.exe' to unpack signatured data to files and install it,

'SafeUnpack.exe' is protected by Digital Signatures,
Right click file to see Properties to confirm it, make sure 'SafeUnpack.exe' is clean.

The 'SafeUnpack.exe' will make sure installed files is safe and is also protected by
'Cute Sticky Notes' private Digital Signatures.

After install, you can use 'SafeLaunch.exe' to run 'Cute Sticky Notes' application,
It will check every installed files private Digital Signatures, make sure no virus infected,
If 'SafeLaunch.exe' check failed, use CuteStickyNotes_Setup.zip re-install will be OK.

23/11/2017